# Meta-MAPG
Source code for ''A Policy Gradient Algorithm for Learning to Learn in Multiagent Reinforcement Learning''

## Dependency
Known dependencies are:
```
python 3.6.5
pip3.6
virtualenv 
numpy 1.14.0
torch 1.3.1
gym 0.12.5
tensorboardX 1.2
```

## Setup
To avoid any conflict, please install virtual environment with [`virtualenv`](http://docs.python-guide.org/en/latest/dev/virtualenvs/):
```
pip3.6 install --upgrade virtualenv
```

## Run
To start training in IPD:
```
./_train.sh
```
Additionally, to see the tensorboard logging during training:
```
tensorboard --logdir=log
```
